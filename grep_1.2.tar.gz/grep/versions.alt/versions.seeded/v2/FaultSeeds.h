/* #define FAULTY_F_DG_1 */
/* #define FAULTY_F_DG_2 */
/* #define FAULTY_F_DG_5 */
/* #define FAULTY_F_KP_1 */
/* #define FAULTY_F_KP_2 */
/* #define FAULTY_F_KP_3 */
/* #define FAULTY_F_KP_4 */
/* #define FAULTY_F_KP_5 */
