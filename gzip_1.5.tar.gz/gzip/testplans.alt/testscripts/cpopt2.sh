if [ -f $experiment_root/gzip/inputs/testdir/file15.gz ]
then
  cp $experiment_root/gzip/inputs/testdir/file15.gz $experiment_root/gzip/outputs/test27
else
  cp $experiment_root/gzip/inputs/testdir/file15.z $experiment_root/gzip/outputs/test27
fi

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
