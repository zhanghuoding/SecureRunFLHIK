cp $experiment_root/gzip/inputs/testdir/subdir2/file $experiment_root/gzip/outputs/test18

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
