cp $experiment_root/gzip/inputs/testdir/subdir1/file $experiment_root/gzip/outputs/test17

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
