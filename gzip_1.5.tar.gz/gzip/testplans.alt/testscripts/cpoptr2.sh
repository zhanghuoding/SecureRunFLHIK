cp $experiment_root/gzip/inputs/testdir/subdir3/file $experiment_root/gzip/outputs/test19

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
