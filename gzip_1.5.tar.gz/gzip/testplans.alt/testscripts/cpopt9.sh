if [ -f $experiment_root/gzip/inputs/testdir/file22.gz ]
then
  cp $experiment_root/gzip/inputs/testdir/file22.gz $experiment_root/gzip/outputs/test34
else
  cp $experiment_root/gzip/inputs/testdir/file22.z $experiment_root/gzip/outputs/test34
fi

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
