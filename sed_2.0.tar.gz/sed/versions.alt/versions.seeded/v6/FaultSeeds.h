/* #define FAULTY_F_KRM_1 */
/* #define FAULTY_F_KRM_4 */
/* #define FAULTY_F_KRM_5 */
/* #define FAULTY_F_KRM_7 */
/* #define FAULTY_F_KRM_8 */
/* #define FAULTY_F_KRM_9 */
