#!/bin/sh

make build
