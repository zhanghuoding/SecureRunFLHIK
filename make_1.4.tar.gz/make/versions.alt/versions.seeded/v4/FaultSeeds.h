/* #define F_JR_1 */
/* #define F_JR_8 */
/* #define F_AA_1 */
/* #define F_AA_4 */
/* #define F_AA_8 */
