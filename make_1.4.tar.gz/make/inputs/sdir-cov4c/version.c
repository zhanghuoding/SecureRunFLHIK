char *version_string = "3.75";

/*
  Local variables:
  version-control: never
  End:
 */
